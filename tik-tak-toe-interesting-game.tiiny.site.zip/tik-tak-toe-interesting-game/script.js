const board = document.getElementById('board');
const resetButton = document.getElementById('resetButton');
const changeSizeButton = document.getElementById('changeSizeButton');
let currentPlayer = 'X';
let gameBoard = ['', '', '', '', '', '', '', '', ''];
let boardSize = 3;

// Create cells
function createBoard() {
    board.innerHTML = '';
    board.style.gridTemplateColumns = `repeat(${boardSize}, 100px)`;

    for (let i = 0; i < boardSize * boardSize; i++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.dataset.index = i;
        cell.addEventListener('click', handleCellClick);
        board.appendChild(cell);
    }
}

createBoard();

resetButton.addEventListener('click', resetGame);
changeSizeButton.addEventListener('click', changeBoardSize);

function handleCellClick(event) {
    const index = event.target.dataset.index;

    if (gameBoard[index] === '' && !checkWinner()) {
        gameBoard[index] = currentPlayer;
        event.target.textContent = currentPlayer;
        updateCellBackgroundColor(event.target, currentPlayer);

        if (checkWinner()) {
            alert(`Player ${currentPlayer} wins!`);
            resetGame();
        } else if (!gameBoard.includes('')) {
            alert('It\'s a draw!');
            resetGame();
        } else {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        }
    }
}

function updateCellBackgroundColor(cell, player) {
    cell.style.backgroundColor = player === 'X' ? '#61dafb' : '#ff6347';
}

function checkWinner() {
    const winConditions = getWinConditions();

    for (const condition of winConditions) {
        const [a, b, c] = condition;
        if (gameBoard[a] !== '' && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
            return true;
        }
    }

    return false;
}

function resetGame() {
    gameBoard = Array(boardSize * boardSize).fill('');
    currentPlayer = 'X';

    const cells = document.querySelectorAll('.cell');
    cells.forEach(cell => {
        cell.textContent = '';
        cell.style.backgroundColor = '#ddd';
    });
}

function changeBoardSize() {
    boardSize = boardSize === 3 ? 4 : 3;
    createBoard();
    resetGame();
}

function getWinConditions() {
    const winConditions = [];
    // Rows
    for (let i = 0; i < boardSize; i++) {
        const row = [];
        for (let j = 0; j < boardSize; j++) {
            row.push(i * boardSize + j);
        }
        winConditions.push(row);
    }
    // Columns
    for (let i = 0; i < boardSize; i++) {
        const col = [];
        for (let j = 0; j < boardSize; j++) {
            col.push(i + j * boardSize);
        }
        winConditions.push(col);
    }
    // Diagonals
    const diag1 = [];
    const diag2 = [];
    for (let i = 0; i < boardSize; i++) {
        diag1.push(i * (boardSize + 1));
        diag2.push((i + 1) * (boardSize - 1));
    }
    winConditions.push(diag1, diag2);

    return winConditions;
}
